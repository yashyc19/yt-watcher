# # Build the project
# 1. Run `poetry build` in the project directory

# # Install the project in the production environment
# 2. Transfer the generated .whl file to the production environment
# 3. In the production environment, run `pip install dist/<your_project>.whl`

# # Run the project
# 4. Run the commands `test-main` and `demo` directly in the command line